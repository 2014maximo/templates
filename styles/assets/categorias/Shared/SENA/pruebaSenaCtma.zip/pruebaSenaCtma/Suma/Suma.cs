﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Suma
{
    public class Suma
    {
        private double num1;
        private double num2;
        private double resultado;
        private string error;
        private string alerta;

        public double gsNum1 { get => num1; set => num1 = value; }
        public double gsNum2 { get => num2; set => num2 = value; }
        public double gsResultado { get => resultado; set => resultado = value; }
        public string gsError { get => error; set => error = value; }
        public string gsAlerta { get => alerta; set => alerta = value; }

        private bool validar() { 

            if(num1 < 0 || num2 < 0) {
                error = "Los valores son negativos";
                return false;
            }

            return true;

        }
    }
}
